import{_ as e,o as c,c as o}from"./index-54934d88.js";const n={};function t(r,s){return c(),o("div",null,"404")}const a=e(n,[["render",t]]);export{a as default};
